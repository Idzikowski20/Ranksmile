<?php
/**
 * Grouped in-app navigation.
 *
 * @package Ranksmile
 */

namespace Ranksmile\Admin\RSDS;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * IA nav.
 */
class Nav {

	/**
	 * @return array<int,array{label?:string,items:array<int,array{slug:string,label:string,disabled?:bool}>}>
	 */
	public static function groups() {
		return array(
			array(
				'items' => array(
					array( 'slug' => 'ranksmile', 'label' => __( 'Dashboard', 'ranksmileseo' ) ),
				),
			),
			array(
				'label' => __( 'Content', 'ranksmileseo' ),
				'items' => array(
					array( 'slug' => 'ranksmile-articles', 'label' => __( 'Articles', 'ranksmileseo' ) ),
					array( 'slug' => 'ranksmile-content-audit', 'label' => __( 'Content Audit', 'ranksmileseo' ) ),
				),
			),
			array(
				'label' => __( 'Search', 'ranksmileseo' ),
				'items' => array(
					array( 'slug' => 'ranksmile-gsc', 'label' => __( 'Google Search Console', 'ranksmileseo' ) ),
				),
			),
			array(
				'label' => __( 'Workspace', 'ranksmileseo' ),
				'items' => array(
					array( 'slug' => 'ranksmile-integrations', 'label' => __( 'Integrations', 'ranksmileseo' ) ),
					array( 'slug' => 'ranksmile-settings', 'label' => __( 'Settings', 'ranksmileseo' ) ),
				),
			),
			array(
				'label' => __( 'Support', 'ranksmileseo' ),
				'items' => array(
					array( 'slug' => 'ranksmile-help', 'label' => __( 'Help', 'ranksmileseo' ) ),
				),
			),
			array(
				'label' => __( 'Insights', 'ranksmileseo' ),
				'items' => array(
					array( 'slug' => 'ranksmile-ai-visibility', 'label' => __( 'AI Visibility', 'ranksmileseo' ), 'disabled' => true ),
					array( 'slug' => 'ranksmile-benchmark', 'label' => __( 'Benchmark', 'ranksmileseo' ), 'disabled' => true ),
					array( 'slug' => 'ranksmile-reports', 'label' => __( 'Reports', 'ranksmileseo' ), 'disabled' => true ),
				),
			),
		);
	}

	/**
	 * @param string $current_slug Current page.
	 * @return string
	 */
	public static function render( $current_slug ) {
		ob_start();
		echo '<nav class="rs-nav" aria-label="' . esc_attr__( 'Ranksmile', 'ranksmileseo' ) . '">';
		foreach ( self::groups() as $group ) {
			echo '<div class="rs-nav__group">';
			if ( ! empty( $group['label'] ) ) {
				echo '<p class="rs-nav__group-label">' . esc_html( $group['label'] ) . '</p>';
			}
			foreach ( $group['items'] as $item ) {
				$disabled = ! empty( $item['disabled'] );
				$active   = ( $item['slug'] === $current_slug );
				$classes  = 'rs-nav__link' . ( $active ? ' is-active' : '' ) . ( $disabled ? ' is-disabled' : '' );
				$url      = $disabled ? '#' : admin_url( 'admin.php?page=' . $item['slug'] );
				echo '<a class="' . esc_attr( $classes ) . '" href="' . esc_url( $url ) . '">' . esc_html( $item['label'] ) . '</a>';
			}
			echo '</div>';
		}
		echo '</nav>';
		return (string) ob_get_clean();
	}
}
