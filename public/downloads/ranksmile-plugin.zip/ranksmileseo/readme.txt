=== Ranksmile – WordPress Plugin  ===
Contributors: ranksmileseo, xingupl, judytafromranksmile 
Tags: seo, keywords, content writing, content, keyword research
Requires at least: 6.0
Requires PHP: 7.4
Tested up to: 6.9
Stable tag: 1.7.0.639
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect Ranksmile's Content Editor to WordPress. Write and optimize your articles for SEO, find new keyword ideas and publish straight to WordPress.

== Description ==

Connect Ranksmile’s Content Editor to WordPress and make writing content, discovering keywords, and optimizing your work for SEO a breeze. 

== RANKSMILE’S OFFICIAL WORDPRESS PLUGIN ==
Ranksmile’s free WordPress plugin that connects your WordPress page to Ranksmile’s Content Editor. Ranksmile’s WP plugin just saved you a step (or 2!). Write, publish and start ranking. 

== EASY SETUP AND FAST INTEGRATION ==
It takes just a few minutes to download and install the plugin, and even less to publish your content!

* Install the free WordPress plugin
* Write highly rankable content using Ranksmile’s trusted guidelines
* Research and find new keyword ideas
* Work in WordPress using Ranksmile’s Content Editor without any hassle
* Create a Content Editor directly in WordPress, or export it to Ranksmile
* Track how many clicks and impressions your posts generated directly in WordPress

== AVOID FORMATTING ISSUES AND INCONSISTENCIES ==
CTRL + A, CTRL + C, CTRL + V, in two clicks! What you write in Ranksmile’s Content Editor is what you’ll get (and see) when you publish on WordPress.

Headings, images and text are converted block by block and transferred seamlessly from Ranksmile’s interface to your WordPress site.

Images are downloaded and stored on WordPress and are accessible in your media library versus an external link which improves performance and SEO!

Ranksmile’s Plugin currently supports the two most widely used WordPress text editors: Gutenberg and Classic Editor (and can distinguish between the two!).

V.1, V.2 V.3? **With Ranksmile plugin you always publish the current and correct version of your article without the copy-paste confusion.**

== OPTIMIZE AND IMPROVE EXISTING ARTICLES ==
Keep your content relevant and competitive with periodic updates to keep climbing the SERPs!

Use Ranksmile’s Content Editor to refresh your article and optimize its keywords for an even better performance.

Finally, once you’re satisfied with the improvements, publish the updated piece on WP. You can also easily access all your WordPress articles in the Content Editor!

== RANKSMILE RESOURCES AND SUPPORT ==
Get your questions answered whenever you need help. Simply go to our [website](https://ranksmile.pl/) and reach out to us via chat, or drop us an email at [support@ranksmile.pl](https://wordpress.org/plugins/ranksmileseo/support@ranksmile.pl).

You can also sign up for [Ranksmile Academy](https://ranksmile.pl/academy/) and learn how to take advantage of Ranksmile with unlimited tips and tricks packaged into training videos and live sessions. For free!

== READ MORE ==
Want more information about Search Engine Optimization and Ranksmile?

* Join our [Facebook Group](https://www.facebook.com/groups/seoranksmiles)
* Find us on [LinkedIn](https://www.linkedin.com/company/ranksmile/) and [YouTube](https://www.youtube.com/c/Ranksmile)
* Check our [Knowledge Base](https://ranksmile.pl/en/) 

== Installation ==

You can install plugin easily and for free, using our [guide](https://ranksmile.pl/en/articles/6328028-wpranksmile-export-the-content-from-content-editor-to-your-wordpress#h_0c607b048f).

In case of any troubles, just go to our [website](https://ranksmile.pl/) and reach out to us via chat, or drop us an email at [support@ranksmile.pl](support@ranksmile.pl).

== Frequently Asked Questions ==

= What is Ranksmile? =
Ranksmile is there to help you with your whole content optimization process. You’ll be able to find new ideas to write about that are backed by what currently ranks in Google, create those pieces of content using data-driven guidelines, and then optimize your already existing pages.

= Is the plugin free? =
Yes, but some features require account in [Ranksmile](https://ranksmile.pl)

= Do I need a Ranksmile account to use this plugin? =
Some features are available right away, and you can use them for free, some features require an account.

= Why there is no support via WordPress forum? =
We want to provide the best and quickest help possible, this is why we provide support via our live chat or eamil. 

It is not a bug, it is a feature. ;)

== Screenshots ==

1. Write and optimize your content directly in WordPress with the Ranksmile WordPress plugin
2. Manage, edit, and optimize your content with Ranksmile’s seamless WordPress plugin. 
3. Create new content and export it from Ranksmile to WordPress with ease.
4. Select prewritten, drafted, pending, future, and published content  and export it to WordPress with just a few clicks.

== Changelog ==

= 1.7.0 =
* FEATURE: Support for Advanced Custom Fields export and import

= 1.6.8 =
* FIX: Improved security & speed
* FIX: Issue with attributes for images during import
* FIX: Elementor duplicated table issue

= 1.6.7 =
* FEATURE: Support for new workspaces in Ranksmile 
* FIX: Improved security & speed
* FIX: Config form save error that randomly occurred
* FIX: CRON reduce logs
* FIX: URLs redirecting to old Ranksmile paths

= 1.6.6 =
* FIX: Issue with importing content
* FIX: Connection issue for servers that not support transients

= 1.6.5 =
* FEATURE: New filters to allow customized content parsing
* FIX: Security improvements
* FIX: Other small fixes & typos

= 1.6.4 =
* FEATURE: Introduce async image loading
* FEATURE: Better log tool for import/export
* FEATURE: Dev tool to manually set API key from wp-admin
* FIX: Issues caused by emojis in content
* FIX: Better handling for unreachable images
* FIX: Missing content during some exports

= 1.6.3 =
* FEATURE: Handle tables export from Ranksmile
* FIX: But that sometimes put whole content into single Text element in Elementor
* FIX: Limit number of tags, categories and users on export list, to avoid errors
* FIX: Remove <p> tag from inside of the <li> elements in lists
* FIX: Prevent post publication date change on export

= 1.6.2 =
* FEATURE: Allow to set rel and target arguments for internal and external links during content import
* FIX: Connection issue that sometimes occurred during exporting from Ranksmile
* FIX: Execute shrotcodes during export from WordPress
* FIX: Other small fixes

= 1.6.1 =
* FEATURE: Developer tool, to remove old Ranksmile Backups
* FIX: searching posts in Ranksmile will be by title only instead of current keyword search
* FIX: Elementor: images caption is counted to content score
* FIX: Hide Grid container notification for new Elementor versions.
* FIX: Set proper target attribute for links


= 1.6.0 =
* FEATURE: Support Meta Tags Import/Export from/to Ranksmile
* FEATURE: Configuration option to disable writing guidelines in Elementor
* FEATURE: Support for files with same name or files with name changed after export from Ranksmile, during saving images in Media Library
* FIX: Notification for conflict between Ranksmile export and Elementor settings
* FIX: GSC reports e-mails with empty "to"
* FIX: Security improvements
* FIX: Typos

= 1.5.0 =
* FEATURE: Elementor integration 
* FIX: REST API authorization issue when redirection is set
* FIX: Writing Guidelines stuck on first load in Classic Editor
* FIX: Parsing special chars in headings during import
* FIX: Missing content issue during export of certain types of images
* FIX: Better support for custom post types in Classic Editor

= 1.4.3 =
* FEATURE: Improvements in Elementor integration (beta)
* FEATURE: Automatic post reconnection (debugging tool)
* FIX: On export from Ranksmile, not all post types were visible on list.
* FIX: On export from WordPress from posts list content sometimes was distorted

= 1.4.2 =
* FEATURE: Content Score details in writing guidelines
* FEATURE: Support for advanced export from Ranksmile
* FEATURE: Help button in sidebar
* Fix: Speed improvements in Gutenberg and Classic Editor
* Fix: Issues with import to Gutenberg
* Fix: Upgraded dependencies versions
* Fix: Code optimization
* Fix: Better support for React 16 (old WordPress versions)

= 1.4.1 =
* Fix: Terms filtering
* Fix: Writing guidelines reloading on sidebar change
* Fix: Issue with disconnection
* Fix: Typos & copy
* Fix: Styling and design issues
* Fix: Other small fixes

= 1.4.0 =
* FEATURE: Ranksmile writing guidelines Sidebar introduced
* FEATURE: Elementor integration (Beta)

= 1.3.4 =
* Fix: Classic editor title issue
* Fix: CRON execution issue

= 1.3.3 =
* FEATURE: Option to force choose parser from config
* Fix: Security update
* Fix: Updated CRON tasks
* Fix: Better versioning for JS files (no more caching conflicts)
* Fix: Resolve notices
* Fix: Missing images on export to Ranksmile from Classic Editor 
* Fix: Better error handling for no credits error

= 1.3.2 =
* Fix: Migration error
* Fix: Drop monitor sorting issue

= 1.3.1 =
* FEATURE: Better handling for images saves
* Fix: Downloading data from GSC 
* Fix: Optimization

= 1.3.0 =
* FEATURE: Position drop monitor - now you will know how your posts perform directly in WordPress!
* FEATURE: Position drop notifications - We will inform you (if you want) about posts position drop via e-mail or WordPress notification. 
* Fix: Duplicate H1 issue
* Fix: Pasting keyword to Content Editor creation
* Fix: JS conflict with some block plugins in Gutenberg
* Fix: Missing title in Classic Editor export
* Fix: Missing content in Classic Editor on late load
* Fix: Submission of Content Editor creation edge cases
* Fix: Optimization of plugin size
* Fix: GSC access capabilities

= 1.2.2 =
* Fix: Timeout error for large posts
* Fix: Posts exported from Ranksmile will be connected 

= 1.2.1 =
* Fix: Better JS file loading
* Fix: Notices

= 1.2.0 =
* FEATURE: We eliminated the 30 day limit for blog posts. Access all of your WordPress articles in Ranksmile's Content Editor.
* FEATURE: You can now create a new Content Editor directly from WordPress. Use it to create new posts and then update them with one click from the WordPress dashboard.
* FEATURE: You can now see the clicks and impressions that your posts gathered in the last 30 days. To unlock it, connect Google Search Console to your Ranksmile account.
* FEATURE: We added (optional) tracking which will allow us to better understand how users interact with the plugin and how to prioritize incoming improvements. 
* Fix: Fixes on commonly know bugs

= 1.1.2 = 
* FEATURE: new hook for post types
* Fix: Fixes on commonly know bugs

= 1.1.1 = 
* FEATURE: Support for headless WordPress
* Fix: Increase import script execution time to solve timeouts (can have no effect, based on server config)
* Fix: CSS optimization
* Fix: Better images parsing for Classic Editor
* Fix: Accessibility improvements
* Fix: Other minor fixes

= 1.1.0 =
* FEATURE: Keyword Research tool
* FEATURE: Add GSC tag into header section
* Fix: Bug fixes

= 1.0.0 =
* FEATURE: Initial release.
* FEATURE: Export content from Ranksmile Content Editor to WordPress.

== Upgrade Notice ==

= 1.7.0 =
Integration with Advanced Custom Fields (ACF) plugin.

= 1.6.8 =
Solve import error for Elementor.

= 1.6.7 =
Required to use new workspaces in Ranksmile. Also better speed and security.

= 1.6.6 =
Solve import error for Elementor and Classic Editor. 

= 1.6.5 =
Security improvements and new content parsing hooks

= 1.6.4 =
Async images download - for content editors with multiple images

= 1.6.3 =
Support for tables export and better exports

= 1.6.2 =
Allow to set attributes for links during import

= 1.6.1 =
Improves Elementor integration and better images handling

= 1.6.0 =
Support for Ranksmile AI Meta Tags

= 1.5.0 =
Elementor Integration

= 1.4.3 =
Fixing post types during import and export.

= 1.4.2 =
Improves Writing Guidelines

= 1.4.1 =
Adds custom filters 

= 1.4.0 =
Ranksmile writing guidelines inside your WordPress (Gutenberg and Classic Editor)

= 1.3.4 =
Fixes Classic Editor issues.

= 1.3.3 =
Improves security.

= 1.3.2 =
Better sorting for position drop monitor.

= 1.3.1 =
Improves images handling.

= 1.3.0 =
Position drop monitor - now you will know how your posts perform directly in WordPress!

= 1.2.2 =
Fix for large posts.

= 1.2.1 =
Speed improvements.

= 1.2.0 =
You can create Content Editor inside Ranksmile from WordPress.

= 1.1.2 = 
New custom hooks.

= 1.1.1 = 
Support for headless WordPress.

= 1.1.0 =
Keyword Research.

= 1.0.0 =
Export content to Ranksmile!
