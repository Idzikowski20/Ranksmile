<?php
/**
 * RSDS Admin Shell — wraps every Ranksmile admin app.
 *
 * Expected vars: $rs_page_slug, $rs_page_title, $rs_page_description,
 * $rs_primary_action (array label/url|null), $rs_secondary_action, $rs_content_template
 *
 * @package Ranksmile
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Ranksmile\Admin\RSDS\Nav;
use Ranksmile\Admin\RSDS\Notices;
use Ranksmile\Admin\RSDS\Status;

$rs_page_slug        = isset( $rs_page_slug ) ? $rs_page_slug : 'ranksmile';
$rs_page_title       = isset( $rs_page_title ) ? $rs_page_title : 'Ranksmile';
$rs_page_description = isset( $rs_page_description ) ? $rs_page_description : '';
$rs_primary_action   = isset( $rs_primary_action ) ? $rs_primary_action : null;
$rs_secondary_action = isset( $rs_secondary_action ) ? $rs_secondary_action : null;
$api_status          = Status::for_api();
$logo                = Ranksmile()->get_baseurl() . 'assets/images/ranksmile_logo.svg';
?>
<div class="wrap ranksmile-admin" data-theme="light">
	<div class="rs-shell">
		<header class="rs-shell__top">
			<div class="rs-shell__brand">
				<img src="<?php echo esc_url( $logo ); ?>" alt="" width="28" height="28" />
				<span class="rs-shell__brand-name">Ranksmile</span>
			</div>
			<div class="rs-shell__meta">
				<span class="rs-badge <?php echo Status::CONNECTED === $api_status['status'] ? 'rs-badge--success' : ''; ?>">
					<?php echo Status::CONNECTED === $api_status['status'] ? esc_html__( 'Connected', 'ranksmileseo' ) : esc_html__( 'Disconnected', 'ranksmileseo' ); ?>
				</span>
				<span><?php echo esc_html( 'v' . RANKSMILE_VERSION ); ?></span>
			</div>
		</header>
		<div class="rs-shell__main">
			<aside class="rs-shell__sidebar">
				<?php echo Nav::render( $rs_page_slug ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</aside>
			<main class="rs-shell__content">
				<p class="rs-breadcrumb">
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=ranksmile' ) ); ?>">Ranksmile</a>
					&nbsp;/&nbsp;<?php echo esc_html( $rs_page_title ); ?>
				</p>
				<?php echo Notices::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<div class="rs-action-bar">
					<div class="rs-action-bar__copy">
						<h1 class="rs-action-bar__title"><?php echo esc_html( $rs_page_title ); ?></h1>
						<?php if ( $rs_page_description ) : ?>
							<p class="rs-action-bar__desc"><?php echo esc_html( $rs_page_description ); ?></p>
						<?php endif; ?>
					</div>
					<div class="rs-action-bar__actions">
						<?php if ( is_array( $rs_secondary_action ) && ! empty( $rs_secondary_action['url'] ) ) : ?>
							<a class="rs-btn rs-btn--secondary" href="<?php echo esc_url( $rs_secondary_action['url'] ); ?>"><?php echo esc_html( $rs_secondary_action['label'] ); ?></a>
						<?php endif; ?>
						<?php if ( is_array( $rs_primary_action ) && ! empty( $rs_primary_action['url'] ) ) : ?>
							<a class="rs-btn rs-btn--primary" href="<?php echo esc_url( $rs_primary_action['url'] ); ?>"><?php echo esc_html( $rs_primary_action['label'] ); ?></a>
						<?php endif; ?>
					</div>
				</div>
				<?php
				if ( ! empty( $rs_content_template ) && file_exists( $rs_content_template ) ) {
					require $rs_content_template;
				}
				?>
			</main>
		</div>
	</div>
</div>
