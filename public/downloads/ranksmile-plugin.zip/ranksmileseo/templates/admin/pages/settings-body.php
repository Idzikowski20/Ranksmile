<?php
/**
 * Settings app body — progressive disclosure.
 *
 * @package Ranksmile
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Ranksmile\Ranksmileseo;

$form    = isset( $rs_settings_form ) ? $rs_settings_form : null;
$section = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'connection'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
if ( ! in_array( $section, array( 'connection', 'tracking', 'editor', 'notifications', 'advanced' ), true ) ) {
	$section = 'connection';
}
$base = admin_url( 'admin.php?page=ranksmile-settings&section=' );
?>
<nav class="rs-nav" style="flex-direction:row;flex-wrap:wrap;gap:var(--rs-space-2);margin-bottom:var(--rs-space-5);padding:0;" aria-label="<?php esc_attr_e( 'Settings sections', 'ranksmileseo' ); ?>">
	<?php
	$tabs = array(
		'connection'    => __( 'Connection', 'ranksmileseo' ),
		'editor'        => __( 'Editor', 'ranksmileseo' ),
		'tracking'      => __( 'Tracking', 'ranksmileseo' ),
		'notifications' => __( 'Notifications', 'ranksmileseo' ),
		'advanced'      => __( 'Advanced', 'ranksmileseo' ),
	);
	foreach ( $tabs as $key => $label ) :
		$active = $section === $key ? ' is-active' : '';
		?>
		<a class="rs-nav__link<?php echo esc_attr( $active ); ?>" href="<?php echo esc_url( $base . $key ); ?>"><?php echo esc_html( $label ); ?></a>
	<?php endforeach; ?>
</nav>

<div class="rs-card">
	<div class="rs-card__body">
		<form action="" method="POST">
			<?php wp_nonce_field( 'ranksmile_settings_save', '_ranksmile_nonce' ); ?>
			<?php if ( $form ) : ?>
				<?php $form->render_admin_form(); ?>
			<?php endif; ?>
			<?php if ( 'advanced' === $section ) : ?>
				<details open>
					<summary style="cursor:pointer;font-weight:600;margin-bottom:var(--rs-space-4);"><?php esc_html_e( 'Advanced & debug', 'ranksmileseo' ); ?></summary>
					<div class="rs-debug-buttons" style="display:flex;flex-wrap:wrap;gap:var(--rs-space-2);">
						<a class="rs-btn rs-btn--secondary rs-btn--sm" target="_blank" href="<?php echo esc_url( admin_url( 'admin.php?page=ranksmile-settings&action=download_debug_data&_wpnonce=' . wp_create_nonce( 'ranksmile_admin_actions' ) ) ); ?>"><?php esc_html_e( 'Download debug data', 'ranksmileseo' ); ?></a>
						<a class="rs-btn rs-btn--secondary rs-btn--sm" target="_blank" href="<?php echo esc_url( admin_url( 'admin.php?page=ranksmile-settings&action=download_import_logs&_wpnonce=' . wp_create_nonce( 'ranksmile_admin_actions' ) ) ); ?>"><?php esc_html_e( 'Download import logs', 'ranksmileseo' ); ?></a>
						<a class="rs-btn rs-btn--secondary rs-btn--sm" target="_blank" href="<?php echo esc_url( admin_url( 'admin.php?page=ranksmile-settings&action=download_export_logs&_wpnonce=' . wp_create_nonce( 'ranksmile_admin_actions' ) ) ); ?>"><?php esc_html_e( 'Download export logs', 'ranksmileseo' ); ?></a>
					</div>
				</details>
			<?php else : ?>
				<details style="margin-top:var(--rs-space-4);">
					<summary style="cursor:pointer;color:var(--rs-text-secondary);"><?php esc_html_e( 'Advanced (collapsed)', 'ranksmileseo' ); ?></summary>
					<p class="rs-hint"><?php esc_html_e( 'Open the Advanced tab for debug downloads and low-level options.', 'ranksmileseo' ); ?></p>
					<a class="rs-btn rs-btn--ghost rs-btn--sm" href="<?php echo esc_url( $base . 'advanced' ); ?>"><?php esc_html_e( 'Go to Advanced', 'ranksmileseo' ); ?></a>
				</details>
			<?php endif; ?>
			<p style="margin-top:var(--rs-space-5);">
				<button type="submit" class="rs-btn rs-btn--primary"><?php esc_html_e( 'Save settings', 'ranksmileseo' ); ?></button>
			</p>
		</form>
	</div>
</div>
