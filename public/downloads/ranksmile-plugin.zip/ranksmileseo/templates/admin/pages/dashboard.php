<?php
/**
 * Dashboard Control Center body.
 *
 * @package Ranksmile
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Ranksmile\Admin\RSDS\Health;
use Ranksmile\Admin\RSDS\Status;

$health = Health::summary();
$api    = Status::for_api();
$gsc    = Status::for_gsc();
$app_url = defined( 'RANKSMILE_APP_URL' ) ? RANKSMILE_APP_URL : 'https://app.ranksmile.pl';
?>
<section class="rs-grid rs-grid--3" style="margin-bottom: var(--rs-space-6);">
	<div class="rs-card"><div class="rs-card__body"><?php echo Status::render( $api['status'], $api ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div>
	<div class="rs-card"><div class="rs-card__body"><?php echo Status::render( $gsc['status'], $gsc ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div>
	<div class="rs-card"><div class="rs-card__body">
		<?php
		echo Status::render( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$health['synced_articles'] > 0 ? Status::CONNECTED : Status::WARNING,
			array(
				'title'       => __( 'WordPress Sync', 'ranksmileseo' ),
				'description' => $health['synced_articles'] > 0
					? sprintf( __( '%d articles linked to Ranksmile drafts.', 'ranksmileseo' ), $health['synced_articles'] )
					: __( 'No synced articles yet. Sync from the editor or app.', 'ranksmileseo' ),
				'action_label'=> __( 'View articles', 'ranksmileseo' ),
				'action_url'  => admin_url( 'admin.php?page=ranksmile-articles' ),
			)
		);
		?>
	</div></div>
</section>

<section class="rs-card" style="margin-bottom: var(--rs-space-6);">
	<div class="rs-card__header"><h2 class="rs-card__title"><?php esc_html_e( 'Quick actions', 'ranksmileseo' ); ?></h2></div>
	<div class="rs-card__body" style="display:flex;flex-wrap:wrap;gap:var(--rs-space-2);">
		<a class="rs-btn rs-btn--primary" href="<?php echo esc_url( admin_url( 'admin.php?page=ranksmile-settings' ) ); ?>"><?php esc_html_e( 'Connect', 'ranksmileseo' ); ?></a>
		<a class="rs-btn rs-btn--secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=ranksmile-articles' ) ); ?>"><?php esc_html_e( 'Sync articles', 'ranksmileseo' ); ?></a>
		<a class="rs-btn rs-btn--secondary" href="<?php echo esc_url( $app_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open app', 'ranksmileseo' ); ?></a>
		<a class="rs-btn rs-btn--secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=ranksmile-content-audit' ) ); ?>"><?php esc_html_e( 'Analyze articles', 'ranksmileseo' ); ?></a>
	</div>
</section>

<section class="rs-grid rs-grid--2">
	<div class="rs-card">
		<div class="rs-card__header"><h2 class="rs-card__title"><?php esc_html_e( 'Plugin Health', 'ranksmileseo' ); ?></h2></div>
		<div class="rs-card__body">
			<p style="font-size:var(--rs-text-2xl);font-weight:700;margin:0 0 var(--rs-space-4);"><?php echo esc_html( (string) $health['score'] ); ?>%</p>
			<ul style="margin:0;padding-left:1.2em;color:var(--rs-text-secondary);">
				<?php foreach ( $health['items'] as $item ) : ?>
					<li><?php echo $item['ok'] ? '✓' : '⚠'; ?> <?php echo esc_html( $item['label'] ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
	<div class="rs-card">
		<div class="rs-card__header"><h2 class="rs-card__title"><?php esc_html_e( 'Insights', 'ranksmileseo' ); ?></h2></div>
		<div class="rs-card__body">
			<p class="rs-hint" style="margin:0;"><?php esc_html_e( 'Recommendations will appear here as you sync content and connect Search Console.', 'ranksmileseo' ); ?></p>
		</div>
	</div>
</section>
