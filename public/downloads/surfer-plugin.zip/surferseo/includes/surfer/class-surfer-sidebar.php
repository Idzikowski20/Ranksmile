<?php
/**
 *  Object that manage sidebar in Gutenberg
 *
 * @package SurferSEO
 * @link https://surferseo.com
 */

namespace SurferSEO\Surfer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use SurferSEO\Surferseo;

/**
 * Object responsible for handling Surfer sidebar.
 */
class Surfer_Sidebar {


	/**
	 * Object construct.
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'include_surfer_sidebar_scripts' ) );

		add_action( 'add_meta_boxes', array( $this, 'add_post_export_meta_box' ) );
	}

	/**
	 * Enqueue sidebar script.
	 */
	public function include_surfer_sidebar_scripts() {

		$screen = get_current_screen();
		if ( ! in_array( $screen->post_type, surfer_return_supported_post_types(), true ) ) {
			return;
		}

		$base_url = Surferseo::get_instance()->get_baseurl();

		wp_enqueue_style(
			'surfer-sidebar',
			$base_url . 'assets/css/surfer-sidebar.css',
			array(),
			SURFER_VERSION
		);
	}

	/**
	 * Creates metabox where we will store writing guidelines in iFrame.
	 *
	 * @return void
	 */
	public function add_post_export_meta_box() {
		$current_screen = get_current_screen();

		$allowed_post_types = surfer_return_supported_post_types();

		// Add meta box only in classic editor (in Gutenberg we have sidebar).
		if ( ! $current_screen->is_block_editor() ) {
			add_meta_box(
				'surfer_export_content',
				__( 'Optimize', 'surferseo' ),
				array( $this, 'render_content_export_box' ),
				$allowed_post_types,
				'side',
				'default'
			);
		}
	}

	/**
	 * Displays content of the content export box
	 *
	 * @return void
	 */
	public function render_content_export_box() {

		?>
			<div key="surfer-guidelines" id="surfer-content-export-box"></div>
		<?php
	}
}
